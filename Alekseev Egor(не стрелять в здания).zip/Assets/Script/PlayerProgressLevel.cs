﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable] public class PlayerProgressLevel
{
    public float BulletDamage;
    public float grenadeDamage;
    public float expirienceForTheNextLevel;
}

